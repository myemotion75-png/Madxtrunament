# Add project specific ProGuard rules here.
# By default, the noise reduction compiler optimizes class names.
-keep class com.example.data.** { *; }
