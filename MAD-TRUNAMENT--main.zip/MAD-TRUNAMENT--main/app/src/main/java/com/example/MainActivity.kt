package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.MainViewModel
import com.example.ui.screens.*
import com.example.ui.theme.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            Theme_MadTournament {
                val mainViewModel: MainViewModel = viewModel()
                val currentScreen by mainViewModel.currentScreen.collectAsState()
                val currentUser by mainViewModel.currentUser.collectAsState()
                val appConfig by mainViewModel.appConfig.collectAsState()

                // Safe Bar Insets Wrapper
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = DeepSpaceDark
                ) {
                    // Check if maintenance mode blocks play login
                    val inMaintenance = appConfig?.maintenanceMode == true
                    val blockUser = inMaintenance && (currentUser == null || !currentUser!!.isAdmin)

                    if (blockUser) {
                        MaintenanceScreen(
                            telegramUrl = appConfig?.contactTelegram ?: "https://t.me/MadTournamentSupport"
                        ) {
                            // Let players logout if they are stuck in maintenance inside
                            mainViewModel.logout()
                        }
                    } else {
                        // Core router selection
                        when (currentScreen) {
                            "login" -> {
                                LoginRegisterScreen(mainViewModel) {
                                    // Callback upon successful auth flow
                                    if (currentUser?.isAdmin == true) {
                                        mainViewModel.setScreen("admin")
                                    } else {
                                        mainViewModel.setScreen("dashboard")
                                    }
                                }
                            }
                            "dashboard" -> {
                                TournamentDashboard(mainViewModel)
                            }
                            "wallet" -> {
                                WalletScreen(mainViewModel)
                            }
                            "tickets" -> {
                                SupportScreen(mainViewModel)
                            }
                            "admin" -> {
                                if (currentUser?.isAdmin == true) {
                                    AdminDashboardScreen(mainViewModel)
                                } else {
                                    mainViewModel.setScreen("login")
                                }
                            }
                            else -> {
                                mainViewModel.logout()
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MaintenanceScreen(telegramUrl: String, onReset: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepSpaceDark),
        contentAlignment = Alignment.Center
    ) {
        // Linear Background Glows
        Box(
            modifier = Modifier
                .size(400.dp)
                .background(
                    Brush.radialGradient(
                        colors = listOf(NeonYellow.copy(alpha = 0.15f), Color.Transparent)
                    )
                )
                .align(Alignment.Center)
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .background(CyberSlateElevated, RoundedCornerShape(20.dp))
                    .border(2.dp, NeonYellow, RoundedCornerShape(20.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Build,
                    contentDescription = "Maintenance Icon",
                    tint = NeonYellow,
                    modifier = Modifier.size(36.dp)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "MAINTENANCE SYSTEM LOCKOUT",
                style = MaterialTheme.typography.headlineLarge.copy(
                    fontSize = 20.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = TextWhite
                ),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Esports operators are upgrading the battle ground maps and security parameters. Registering and tournament joining is locked temporarily.",
                style = MaterialTheme.typography.bodyMedium.copy(
                    lineHeight = 20.sp,
                    color = TextSoftAccent
                ),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Telegram Helpline
            Card(
                colors = CardDefaults.cardColors(containerColor = CyberSlateElevated),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, NeoTeal.copy(0.4f), RoundedCornerShape(10.dp))
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(Icons.Default.Send, contentDescription = null, tint = NeoTeal)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text("Connect On Support Telegram", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text(telegramUrl, color = NeoTeal, fontSize = 11.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = onReset,
                colors = ButtonDefaults.buttonColors(containerColor = CyberRed)
            ) {
                Text("BACK TO SIGN-IN SCREEN", color = TextWhite, fontWeight = FontWeight.Bold)
            }
        }
    }
}
