package com.example.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val username: String,
    val email: String,
    val walletBalance: Double = 0.0,
    val isAdmin: Boolean = false,
    val isBlocked: Boolean = false
)

@Entity(tableName = "matches")
data class MatchEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val gameName: String, // Free Fire, BGMI, etc.
    val title: String,
    val dateTime: String,
    val totalPrize: Double,
    val entryFee: Double,
    val killPrize: Double = 0.0,
    val map: String = "Bermuda",
    val matchType: String = "Solo", // Solo, Duo, Squad
    val maxPlayers: Int = 48,
    val joinedCount: Int = 0,
    val isCompleted: Boolean = false,
    val winnerName: String = "",
    val roomCredentials: String = "" // "ID: 483920 | Pass: 1234"
)

@Entity(tableName = "registrations")
data class RegistrationEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val userId: Int,
    val matchId: Int,
    val inGameName: String,
    val inGameId: String,
    val status: String = "Pending" // "Pending", "Approved", "Rejected"
)

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val userId: Int,
    val amount: Double,
    val type: String, // "DEPOSIT", "WITHDRAW", "ENTRY_FEE", "WINNING"
    val methodOrDetails: String, // "Bkash", "Nagad", "Rocket"
    val timestamp: Long = System.currentTimeMillis(),
    val status: String = "Pending" // "Pending", "Success", "Rejected"
)

@Entity(tableName = "tickets")
data class TicketEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val userId: Int,
    val subject: String,
    val message: String,
    val reply: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val status: String = "Open" // "Open", "Resolved"
)

@Entity(tableName = "app_config")
data class ConfigEntity(
    @PrimaryKey val id: Int = 1,
    val maintenanceMode: Boolean = false,
    val minDeposit: Double = 50.0,
    val minWithdraw: Double = 100.0,
    val contactTelegram: String = "http://t.me/MadTournamentSupport"
)

@Dao
interface TournamentDao {
    // Users
    @Query("SELECT * FROM users WHERE email = :email LIMIT 1")
    suspend fun getUserByEmail(email: String): UserEntity?

    @Query("SELECT * FROM users WHERE id = :id LIMIT 1")
    fun getUserById(id: Int): Flow<UserEntity?>

    @Query("SELECT * FROM users")
    fun getAllUsers(): Flow<List<UserEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity): Long

    @Update
    suspend fun updateUser(user: UserEntity)

    // Matches
    @Query("SELECT * FROM matches ORDER BY id DESC")
    fun getAllMatches(): Flow<List<MatchEntity>>

    @Query("SELECT * FROM matches WHERE id = :id")
    fun getMatchById(id: Int): Flow<MatchEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMatch(match: MatchEntity): Long

    @Update
    suspend fun updateMatch(match: MatchEntity)

    @Delete
    suspend fun deleteMatch(match: MatchEntity)

    // Registrations
    @Query("SELECT * FROM registrations WHERE userId = :userId")
    fun getRegistrationsForUser(userId: Int): Flow<List<RegistrationEntity>>

    @Query("SELECT * FROM registrations WHERE matchId = :matchId")
    fun getRegistrationsForMatch(matchId: Int): Flow<List<RegistrationEntity>>

    @Query("SELECT * FROM registrations")
    fun getAllRegistrations(): Flow<List<RegistrationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRegistration(registration: RegistrationEntity)

    @Update
    suspend fun updateRegistration(registration: RegistrationEntity)

    // Transactions
    @Query("SELECT * FROM transactions WHERE userId = :userId ORDER BY timestamp DESC")
    fun getTransactionsForUser(userId: Int): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions ORDER BY timestamp DESC")
    fun getAllTransactions(): Flow<List<TransactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: TransactionEntity): Long

    @Update
    suspend fun updateTransaction(transaction: TransactionEntity)

    // Tickets
    @Query("SELECT * FROM tickets WHERE userId = :userId ORDER BY timestamp DESC")
    fun getTicketsForUser(userId: Int): Flow<List<TicketEntity>>

    @Query("SELECT * FROM tickets ORDER BY timestamp DESC")
    fun getAllTickets(): Flow<List<TicketEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTicket(ticket: TicketEntity)

    @Update
    suspend fun updateTicket(ticket: TicketEntity)

    // App Config
    @Query("SELECT * FROM app_config WHERE id = 1")
    fun getAppConfig(): Flow<ConfigEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveAppConfig(config: ConfigEntity)
}

@Database(
    entities = [
        UserEntity::class,
        MatchEntity::class,
        RegistrationEntity::class,
        TransactionEntity::class,
        TicketEntity::class,
        ConfigEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class TournamentDatabase : RoomDatabase() {
    abstract fun dao(): TournamentDao

    companion object {
        @Volatile
        private var INSTANCE: TournamentDatabase? = null

        fun getDatabase(context: Context): TournamentDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    TournamentDatabase::class.java,
                    "mad_tournament_db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
