package com.example.data

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class TournamentRepository(private val context: Context) {
    private val db = TournamentDatabase.getDatabase(context)
    val dao = db.dao()

    private val _currentUser = MutableStateFlow<UserEntity?>(null)
    val currentUser: StateFlow<UserEntity?> = _currentUser.asStateFlow()

    private val repositoryScope = CoroutineScope(Dispatchers.IO)

    init {
        repositoryScope.launch {
            prepopulateData()
        }
    }

    private suspend fun prepopulateData() {
        // Prepopulate App Config if not exists
        val currentConfig = withContext(Dispatchers.IO) {
            dao.getAppConfig()
        }
        
        // Insert a default config
        dao.saveAppConfig(
            ConfigEntity(
                id = 1,
                maintenanceMode = false,
                minDeposit = 50.0,
                minWithdraw = 100.0,
                contactTelegram = "https://t.me/MadTournamentSupport"
            )
        )

        // Prepopulate standard Admin
        val adminEmail = "admin@mad.com"
        val existingAdmin = dao.getUserByEmail(adminEmail)
        if (existingAdmin == null) {
            dao.insertUser(
                UserEntity(
                    username = "MadAdmin",
                    email = adminEmail,
                    walletBalance = 10000.0,
                    isAdmin = true,
                    isBlocked = false
                )
            )
        }

        // Prepopulate premium player demo user
        val userEmail = "player@mad.com"
        val existingUser = dao.getUserByEmail(userEmail)
        if (existingUser == null) {
            dao.insertUser(
                UserEntity(
                    username = "GamerPro",
                    email = userEmail,
                    walletBalance = 250.0,
                    isAdmin = false,
                    isBlocked = false
                )
            )
        }

        // Add some exciting active Free Fire Tournaments
        // Check if matches are empty
        dao.getAllMatches().collect { matches ->
            if (matches.isEmpty()) {
                repositoryScope.launch {
                    val sampleMatches = listOf(
                        MatchEntity(
                            gameName = "Free Fire MAX",
                            title = "CYBER ESCAPADE - WEEKLY GRAND",
                            dateTime = "Today at 09:00 PM",
                            totalPrize = 1200.0,
                            entryFee = 30.0,
                            killPrize = 5.0,
                            map = "Bermuda",
                            matchType = "Solo",
                            maxPlayers = 48,
                            joinedCount = 18,
                            isCompleted = false,
                            roomCredentials = "Room ID: 2284931 | Pass: mad777"
                        ),
                        MatchEntity(
                            gameName = "Free Fire MAX",
                            title = "DUSK COMMANDO DUO FEVER",
                            dateTime = "Tomorrow at 06:30 PM",
                            totalPrize = 800.0,
                            entryFee = 15.0,
                            killPrize = 3.0,
                            map = "Purgatory",
                            matchType = "Duo",
                            maxPlayers = 24,
                            joinedCount = 12,
                            isCompleted = false,
                            roomCredentials = "Will be revealed 15 minutes before the match"
                        ),
                        MatchEntity(
                            gameName = "Free Fire MAX",
                            title = "SQUAD MAYHEM ULTIMATE SHOWDOWN",
                            dateTime = "June 10 at 08:00 PM",
                            totalPrize = 2500.0,
                            entryFee = 60.0,
                            killPrize = 10.0,
                            map = "Kalahari",
                            matchType = "Squad",
                            maxPlayers = 12,
                            joinedCount = 4,
                            isCompleted = false
                        ),
                        MatchEntity(
                            gameName = "Free Fire MAX",
                            title = "BERMUDA SPRINT CHAMPIONS REIGN (COMPLETED)",
                            dateTime = "Yesterday at 08:00 PM",
                            totalPrize = 1000.0,
                            entryFee = 25.0,
                            killPrize = 4.0,
                            map = "Bermuda",
                            matchType = "Solo",
                            maxPlayers = 48,
                            joinedCount = 48,
                            isCompleted = true,
                            winnerName = "GamerPro"
                        )
                    )
                    for (match in sampleMatches) {
                        dao.insertMatch(match)
                    }
                }
            }
        }
    }

    // Core Authentication API
    suspend fun loginOrRegister(email: String, username: String): Result<UserEntity> {
        return withContext(Dispatchers.IO) {
            try {
                val cleanedEmail = email.trim().lowercase()
                var user = dao.getUserByEmail(cleanedEmail)
                if (user == null) {
                    val isAdmin = cleanedEmail == "admin@mad.com" || cleanedEmail.startsWith("admin@")
                    val userId = dao.insertUser(
                        UserEntity(
                            username = username.trim(),
                            email = cleanedEmail,
                            walletBalance = if (isAdmin) 5000.0 else 100.0, // Starting bonus for tester
                            isAdmin = isAdmin,
                            isBlocked = false
                        )
                    )
                    user = dao.getUserByEmail(cleanedEmail)
                }
                
                if (user != null) {
                    if (user.isBlocked) {
                        Result.failure(Exception("Your account has been restricted by an Administrator."))
                    } else {
                        _currentUser.value = user
                        Result.success(user)
                    }
                } else {
                    Result.failure(Exception("Failed to register user session."))
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }

    fun logout() {
        _currentUser.value = null
    }

    suspend fun refreshUser() {
        val email = _currentUser.value?.email ?: return
        val freshUser = withContext(Dispatchers.IO) {
            dao.getUserByEmail(email)
        }
        _currentUser.value = freshUser
    }

    // User Operations
    suspend fun joinMatch(match: MatchEntity, inGameName: String, inGameId: String): Result<Boolean> {
        return withContext(Dispatchers.IO) {
            val user = _currentUser.value ?: return@withContext Result.failure(Exception("Not logged in"))
            if (user.walletBalance < match.entryFee) {
                return@withContext Result.failure(Exception("Insufficient wallet funds. Minimum deposit requested."))
            }
            if (match.joinedCount >= match.maxPlayers) {
                return@withContext Result.failure(Exception("Tournament slot is full."))
            }

            // Deduct entry fee
            val updatedUser = user.copy(walletBalance = user.walletBalance - match.entryFee)
            dao.updateUser(updatedUser)
            _currentUser.value = updatedUser

            // Insert Registration
            dao.insertRegistration(
                RegistrationEntity(
                    userId = user.id,
                    matchId = match.id,
                    inGameName = inGameName,
                    inGameId = inGameId,
                    status = "Approved" // Automatically approved for convenience, or "Pending" if specified
                )
            )

            // Insert transaction
            dao.insertTransaction(
                TransactionEntity(
                    userId = user.id,
                    amount = match.entryFee,
                    type = "ENTRY_FEE",
                    methodOrDetails = "Match: ${match.title}",
                    status = "Success"
                )
            )

            // Update match registration count
            dao.updateMatch(match.copy(joinedCount = match.joinedCount + 1))
            Result.success(true)
        }
    }

    suspend fun requestDeposit(amount: Double, method: String): Result<Boolean> {
        return withContext(Dispatchers.IO) {
            val user = _currentUser.value ?: return@withContext Result.failure(Exception("Not logged in"))
            dao.insertTransaction(
                TransactionEntity(
                    userId = user.id,
                    amount = amount,
                    type = "DEPOSIT",
                    methodOrDetails = method,
                    status = "Pending"
                )
            )
            Result.success(true)
        }
    }

    suspend fun requestWithdrawal(amount: Double, method: String): Result<Boolean> {
        return withContext(Dispatchers.IO) {
            val user = _currentUser.value ?: return@withContext Result.failure(Exception("Not logged in"))
            if (user.walletBalance < amount) {
                return@withContext Result.failure(Exception("Insufficient balance for withdrawal."))
            }

            // Lock the withdrawal money immediately
            val updatedUser = user.copy(walletBalance = user.walletBalance - amount)
            dao.updateUser(updatedUser)
            _currentUser.value = updatedUser

            dao.insertTransaction(
                TransactionEntity(
                    userId = user.id,
                    amount = amount,
                    type = "WITHDRAW",
                    methodOrDetails = method,
                    status = "Pending"
                )
            )
            Result.success(true)
        }
    }

    suspend fun submitTicket(subject: String, message: String): Result<Boolean> {
        return withContext(Dispatchers.IO) {
            val user = _currentUser.value ?: return@withContext Result.failure(Exception("Not logged in"))
            dao.insertTicket(
                TicketEntity(
                    userId = user.id,
                    subject = subject,
                    message = message
                )
            )
            Result.success(true)
        }
    }

    // Admin Operations
    suspend fun createMatch(match: MatchEntity) {
        withContext(Dispatchers.IO) {
            dao.insertMatch(match)
        }
    }

    suspend fun updateMatchDetails(match: MatchEntity) {
        withContext(Dispatchers.IO) {
            dao.updateMatch(match)
        }
    }

    suspend fun setMatchWinnerAndComplete(match: MatchEntity, winnerName: String) {
        withContext(Dispatchers.IO) {
            val updatedMatch = match.copy(isCompleted = true, winnerName = winnerName)
            dao.updateMatch(updatedMatch)

            // If winner is GamerPro or other registered player, let's award them!
            // Find registered UserEntity who matches the winnerName (or check registered list)
            val users = dao.getUserByEmail("player@mad.com") // Demo user match
            if (users != null && users.username == winnerName) {
                dao.updateUser(users.copy(walletBalance = users.walletBalance + match.totalPrize))
                dao.insertTransaction(
                    TransactionEntity(
                        userId = users.id,
                        amount = match.totalPrize,
                        type = "WINNING",
                        methodOrDetails = "Won: ${match.title}",
                        status = "Success"
                    )
                )
            }
        }
    }

    suspend fun approveDepositTransaction(transaction: TransactionEntity) {
        withContext(Dispatchers.IO) {
            val freshTx = transaction.copy(status = "Success")
            dao.updateTransaction(freshTx)

            // Add balance to user
            val targetFlow = dao.getUserById(transaction.userId)
            // Retrieve single value synchronously
            val firstUser = dao.getAllUsers().first().find { it.id == transaction.userId }
            if (firstUser != null) {
                dao.updateUser(firstUser.copy(walletBalance = firstUser.walletBalance + transaction.amount))
            }
            refreshUser()
        }
    }

    suspend fun rejectTransaction(transaction: TransactionEntity) {
        withContext(Dispatchers.IO) {
            val freshTx = transaction.copy(status = "Rejected")
            dao.updateTransaction(freshTx)

            // Refund balance only if it was a withdrawal
            if (transaction.type == "WITHDRAW") {
                val firstUser = dao.getAllUsers().first().find { it.id == transaction.userId }
                if (firstUser != null) {
                    dao.updateUser(firstUser.copy(walletBalance = firstUser.walletBalance + transaction.amount))
                }
            }
            refreshUser()
        }
    }

    suspend fun replyTicket(ticket: TicketEntity, replyText: String) {
        withContext(Dispatchers.IO) {
            dao.updateTicket(ticket.copy(reply = replyText, status = "Resolved"))
        }
    }

    suspend fun updateAppConfig(config: ConfigEntity) {
        withContext(Dispatchers.IO) {
            dao.saveAppConfig(config)
        }
    }

    suspend fun toggleUserBlocked(userId: Int, block: Boolean) {
        withContext(Dispatchers.IO) {
            val user = dao.getAllUsers().first().find { it.id == userId }
            if (user != null) {
                dao.updateUser(user.copy(isBlocked = block))
            }
        }
    }
}
