package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = TournamentRepository(application)
    val dao = repository.dao

    // Navigation state
    private val _currentScreen = MutableStateFlow("login")
    val currentScreen: StateFlow<String> = _currentScreen.asStateFlow()

    // Active User State
    val currentUser: StateFlow<UserEntity?> = repository.currentUser

    // States from local DB flows
    val appConfig: StateFlow<ConfigEntity?> = dao.getAppConfig().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = null
    )

    val matchesList: StateFlow<List<MatchEntity>> = dao.getAllMatches().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val myRegistrations: StateFlow<List<RegistrationEntity>> = currentUser.flatMapLatest { user ->
        if (user != null) dao.getRegistrationsForUser(user.id) else flowOf(emptyList())
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val myTransactions: StateFlow<List<TransactionEntity>> = currentUser.flatMapLatest { user ->
        if (user != null) dao.getTransactionsForUser(user.id) else flowOf(emptyList())
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val myTickets: StateFlow<List<TicketEntity>> = currentUser.flatMapLatest { user ->
        if (user != null) dao.getTicketsForUser(user.id) else flowOf(emptyList())
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Admin dashboard specific flows (available only for admin user sessions)
    val adminAllUsers: StateFlow<List<UserEntity>> = dao.getAllUsers().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val adminAllTransactions: StateFlow<List<TransactionEntity>> = dao.getAllTransactions().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val adminAllTickets: StateFlow<List<TicketEntity>> = dao.getAllTickets().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val adminAllRegistrations: StateFlow<List<RegistrationEntity>> = dao.getAllRegistrations().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // General messages and visual status feedback
    private val _uiError = MutableStateFlow<String?>(null)
    val uiError: StateFlow<String?> = _uiError.asStateFlow()

    private val _uiSuccess = MutableStateFlow<String?>(null)
    val uiSuccess: StateFlow<String?> = _uiSuccess.asStateFlow()

    fun clearMessages() {
        _uiError.value = null
        _uiSuccess.value = null
    }

    fun setScreen(screen: String) {
        _currentScreen.value = screen
    }

    // UI Operations
    fun login(email: String, username: String) {
        viewModelScope.launch {
            if (email.isBlank() || username.isBlank()) {
                _uiError.value = "Email and Username cannot be empty!"
                return@launch
            }
            val res = repository.loginOrRegister(email, username)
            res.onSuccess { user ->
                clearMessages()
                if (user.isAdmin) {
                    _currentScreen.value = "admin"
                } else {
                    _currentScreen.value = "dashboard"
                }
            }
            res.onFailure { t ->
                _uiError.value = t.message ?: "Authentication failed."
            }
        }
    }

    fun logout() {
        repository.logout()
        _currentScreen.value = "login"
        clearMessages()
    }

    fun joinMatch(match: MatchEntity, inGameName: String, inGameId: String) {
        viewModelScope.launch {
            if (inGameName.isBlank() || inGameId.isBlank()) {
                _uiError.value = "In-game nickname and ID are required!"
                return@launch
            }
            val res = repository.joinMatch(match, inGameName, inGameId)
            res.onSuccess {
                _uiSuccess.value = "Registered successfully for match ${match.title}!"
            }
            res.onFailure { t ->
                _uiError.value = t.message ?: "Failed to join tournament."
            }
        }
    }

    fun depositMoney(amount: Double, method: String) {
        viewModelScope.launch {
            val minDep = appConfig.value?.minDeposit ?: 50.0
            if (amount < minDep) {
                _uiError.value = "Minimum deposit amount is ৳${minDep}"
                return@launch
            }
            val res = repository.requestDeposit(amount, method)
            res.onSuccess {
                _uiSuccess.value = "Deposit request submitted. Admin will review the txn."
            }
            res.onFailure { t ->
                _uiError.value = t.message
            }
        }
    }

    fun withdrawMoney(amount: Double, methodAndNumber: String) {
        viewModelScope.launch {
            val minWith = appConfig.value?.minWithdraw ?: 100.0
            if (amount < minWith) {
                _uiError.value = "Minimum withdrawal amount is ৳${minWith}"
                return@launch
            }
            val res = repository.requestWithdrawal(amount, methodAndNumber)
            res.onSuccess {
                _uiSuccess.value = "Withdrawal request submitted. Your funds are temporarily held."
            }
            res.onFailure { t ->
                _uiError.value = t.message
            }
        }
    }

    fun submitSupportTicket(subject: String, message: String) {
        viewModelScope.launch {
            if (subject.isBlank() || message.isBlank()) {
                _uiError.value = "Please fill in all ticket details."
                return@launch
            }
            val res = repository.submitTicket(subject, message)
            res.onSuccess {
                _uiSuccess.value = "Support ticket submitted. Check back soon for replies."
            }
            res.onFailure { t ->
                _uiError.value = t.message
            }
        }
    }

    // Admin operations
    fun adminCreateMatch(match: MatchEntity) {
        viewModelScope.launch {
            repository.createMatch(match)
            _uiSuccess.value = "Tournament match successfully created!"
        }
    }

    fun adminUpdateMatch(match: MatchEntity) {
        viewModelScope.launch {
            repository.updateMatchDetails(match)
            _uiSuccess.value = "Match was successfully updated."
        }
    }

    fun adminSetWinner(match: MatchEntity, winnerName: String) {
        viewModelScope.launch {
            repository.setMatchWinnerAndComplete(match, winnerName)
            _uiSuccess.value = "Match marked completed. Admin awarded prizes to winner."
        }
    }

    fun adminApproveTransaction(transaction: TransactionEntity) {
        viewModelScope.launch {
            repository.approveDepositTransaction(transaction)
            _uiSuccess.value = "Transaction request marked APPROVED. User balance adjusted."
        }
    }

    fun adminRejectTransaction(transaction: TransactionEntity) {
        viewModelScope.launch {
            repository.rejectTransaction(transaction)
            _uiSuccess.value = "Transaction request marked REJECTED."
        }
    }

    fun adminReplyTicket(ticket: TicketEntity, response: String) {
        viewModelScope.launch {
            if (response.isBlank()) return@launch
            repository.replyTicket(ticket, response)
            _uiSuccess.value = "Replied and resolved ticket #${ticket.id}."
        }
    }

    fun adminSaveConfig(config: ConfigEntity) {
        viewModelScope.launch {
            repository.updateAppConfig(config)
            _uiSuccess.value = "Global application configurations updated."
        }
    }

    fun adminToggleBlockUser(userId: Int, block: Boolean) {
        viewModelScope.launch {
            repository.toggleUserBlocked(userId, block)
            _uiSuccess.value = if (block) "User was restricted." else "User restriction is removed."
        }
    }
}
