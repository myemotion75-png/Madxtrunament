package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.MainViewModel
import com.example.ui.theme.*

@Composable
fun AdminDashboardScreen(viewModel: MainViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    var adminActiveTab by remember { mutableStateOf("MATCHES") } // MATCHES, FINANCES, TICKETS, SETTINGS

    val matches by viewModel.matchesList.collectAsState()
    val allTransactions by viewModel.adminAllTransactions.collectAsState()
    val allTickets by viewModel.adminAllTickets.collectAsState()
    val allUsers by viewModel.adminAllUsers.collectAsState()
    val appConfig by viewModel.appConfig.collectAsState()

    val uiError by viewModel.uiError.collectAsState()
    val uiSuccess by viewModel.uiSuccess.collectAsState()

    DisposableEffect(Unit) {
        onDispose { viewModel.clearMessages() }
    }

    Scaffold(
        topBar = {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CyberSlate)
                    .padding(16.dp)
            ) {
                Text(
                    text = "MAD TOURNAMENT CREATOR CONTROL",
                    color = CyberRed,
                    fontWeight = FontWeight.Black,
                    fontSize = 16.sp,
                    modifier = Modifier.align(Alignment.CenterStart)
                )

                Text(
                    text = "TO USER DASHBOARD",
                    color = NeoTeal,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .clickable { viewModel.setScreen("dashboard") }
                )
            }
        },
        bottomBar = {
            NavigationBar(
                containerColor = CyberSlate,
                modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
            ) {
                NavigationBarItem(
                    selected = adminActiveTab == "MATCHES",
                    onClick = { adminActiveTab = "MATCHES" },
                    icon = { Icon(Icons.Default.PlayArrow, contentDescription = null, tint = if (adminActiveTab == "MATCHES") CyberRed else TextSoftAccent) },
                    label = { Text("Match Maker", color = if (adminActiveTab == "MATCHES") TextWhite else TextSoftAccent, fontSize = 10.sp) }
                )

                NavigationBarItem(
                    selected = adminActiveTab == "FINANCES",
                    onClick = { adminActiveTab = "FINANCES" },
                    icon = { Icon(Icons.Default.Build, contentDescription = null, tint = if (adminActiveTab == "FINANCES") CyberRed else TextSoftAccent) },
                    label = { Text("Payments", color = if (adminActiveTab == "FINANCES") TextWhite else TextSoftAccent, fontSize = 10.sp) }
                )

                NavigationBarItem(
                    selected = adminActiveTab == "TICKETS",
                    onClick = { adminActiveTab = "TICKETS" },
                    icon = { Icon(Icons.Default.Send, contentDescription = null, tint = if (adminActiveTab == "TICKETS") CyberRed else TextSoftAccent) },
                    label = { Text("Tickets", color = if (adminActiveTab == "TICKETS") TextWhite else TextSoftAccent, fontSize = 10.sp) }
                )

                NavigationBarItem(
                    selected = adminActiveTab == "SETTINGS",
                    onClick = { adminActiveTab = "SETTINGS" },
                    icon = { Icon(Icons.Default.Add, contentDescription = null, tint = if (adminActiveTab == "SETTINGS") CyberRed else TextSoftAccent) },
                    label = { Text("Global Config", color = if (adminActiveTab == "SETTINGS") TextWhite else TextSoftAccent, fontSize = 10.sp) }
                )
            }
        },
        containerColor = DeepSpaceDark
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            // Error / Success feedback
            if (uiSuccess != null) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = NeonGreen.copy(0.12f)),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                ) {
                    Text(uiSuccess ?: "", color = NeonGreen, fontWeight = FontWeight.Bold, modifier = Modifier.padding(10.dp), fontSize = 12.sp)
                }
            }
            if (uiError != null) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CyberRed.copy(0.12f)),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                ) {
                    Text(uiError ?: "", color = CyberRed, fontWeight = FontWeight.Bold, modifier = Modifier.padding(10.dp), fontSize = 12.sp)
                }
            }

            when (adminActiveTab) {
                "MATCHES" -> AdminMatchesSubScreen(viewModel, matches)
                "FINANCES" -> AdminPaymentsSubScreen(viewModel, allTransactions, allUsers)
                "TICKETS" -> AdminTicketsSubScreen(viewModel, allTickets)
                "SETTINGS" -> AdminSettingsSubScreen(viewModel, appConfig)
            }
        }
    }
}


// -------------------------------------------------------------
// 1. ADMIN MATCH MAKER SUB-SCREEN & FORMS
// -------------------------------------------------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminMatchesSubScreen(viewModel: MainViewModel, matches: List<MatchEntity>) {
    var showCreateForm by remember { mutableStateOf(false) }

    var title by remember { mutableStateOf("") }
    var fee by remember { mutableStateOf("") }
    val prize by remember { mutableStateOf("1200") }
    val killPrize by remember { mutableStateOf("5") }
    var roomCreds by remember { mutableStateOf("") }

    if (showCreateForm) {
        Card(
            colors = CardDefaults.cardColors(containerColor = CyberSlate),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().border(1.dp, BorderRed, RoundedCornerShape(12.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("CREATE GENERAL TOURNAMENT MATCH", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Match Title (e.g. ULTRA SQUAD MATCH #52)", color = TextSoftAccent) },
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextWhite, unfocusedTextColor = TextWhite, focusedBorderColor = NeoTeal, unfocusedBorderColor = DeepSpaceDark),
                    modifier = Modifier.fillMaxWidth().testTag("admin_match_title_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = fee,
                        onValueChange = { fee = it },
                        label = { Text("Entry Fee (৳)", color = TextSoftAccent) },
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextWhite, unfocusedTextColor = TextWhite, focusedBorderColor = NeoTeal, unfocusedBorderColor = DeepSpaceDark),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f).testTag("admin_match_fee_input")
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = roomCreds,
                    onValueChange = { roomCreds = it },
                    label = { Text("Default Room Credentials (ID/Pass)", color = TextSoftAccent) },
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextWhite, unfocusedTextColor = TextWhite, focusedBorderColor = NeoTeal, unfocusedBorderColor = DeepSpaceDark),
                    modifier = Modifier.fillMaxWidth().testTag("admin_match_room_input")
                )

                Spacer(modifier = Modifier.height(14.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = {
                            if (title.isNotBlank() && fee.isNotBlank()) {
                                viewModel.adminCreateMatch(
                                    MatchEntity(
                                        gameName = "Free Fire MAX",
                                        title = title,
                                        dateTime = "Today at 09:30 PM",
                                        totalPrize = prize.toDoubleOrNull() ?: 1000.0,
                                        entryFee = fee.toDoubleOrNull() ?: 20.0,
                                        killPrize = killPrize.toDoubleOrNull() ?: 5.0,
                                        roomCredentials = roomCreds
                                    )
                                )
                                showCreateForm = false
                                title = ""
                                fee = ""
                                roomCreds = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CyberRed),
                        modifier = Modifier.weight(1f).testTag("admin_match_submit_button")
                    ) {
                        Text("SAVE FIGHT")
                    }

                    Button(
                        onClick = { showCreateForm = false },
                        colors = ButtonDefaults.buttonColors(containerColor = CyberSlateElevated),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("CANCEL", color = TextWhite)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))
    } else {
        Button(
            onClick = { showCreateForm = true },
            colors = ButtonDefaults.buttonColors(containerColor = NeoTeal),
            modifier = Modifier.fillMaxWidth().padding(bottom = 14.dp),
            shape = RoundedCornerShape(8.dp)
        ) {
            Text("ADD NEW MATCH", color = DeepSpaceDark, fontWeight = FontWeight.Bold)
        }
    }

    // List standard matches for editing Room ID or Completing
    Text("ONGOING MATCH LISTS", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)

    Spacer(modifier = Modifier.height(10.dp))

    if (matches.isEmpty()) {
        Box(
            modifier = Modifier.fillMaxWidth().height(100.dp).background(CyberSlate, RoundedCornerShape(8.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text("No tournaments built yet.", color = TextSoftAccent, fontSize = 12.sp)
        }
    } else {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(matches) { match ->
                AdminMatchRow(viewModel, match)
            }
        }
    }
}

@Composable
fun AdminMatchRow(viewModel: MainViewModel, match: MatchEntity) {
    var updateRoomStr by remember { mutableStateOf("") }
    var isEditingRoom by remember { mutableStateOf(false) }

    Card(
        colors = CardDefaults.cardColors(containerColor = CyberSlateElevated),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(match.title, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(
                "Fee: ৳${match.entryFee} | Prize: ৳${match.totalPrize} | Joined: ${match.joinedCount}/${match.maxPlayers}",
                color = TextSoftAccent,
                fontSize = 12.sp
            )
            Text("Creds: ${match.roomCredentials}", color = NeoTeal, fontSize = 11.sp, modifier = Modifier.padding(vertical = 4.dp))

            Spacer(modifier = Modifier.height(8.dp))

            if (!match.isCompleted) {
                if (isEditingRoom) {
                    OutlinedTextField(
                        value = updateRoomStr,
                        onValueChange = { updateRoomStr = it },
                        label = { Text("New ID/Pass Room credentials", color = TextSoftAccent) },
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextWhite, unfocusedTextColor = TextWhite, focusedBorderColor = NeoTeal, unfocusedBorderColor = DeepSpaceDark),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                viewModel.adminUpdateMatch(match.copy(roomCredentials = updateRoomStr))
                                isEditingRoom = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("SAVE KEY", color = DeepSpaceDark)
                        }

                        Button(
                            onClick = { isEditingRoom = false },
                            colors = ButtonDefaults.buttonColors(containerColor = DeepSpaceDark),
                            modifier = Modifier.weight(1.5f)
                        ) {
                            Text("CANCEL", color = TextWhite)
                        }
                    }
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { isEditingRoom = true; updateRoomStr = match.roomCredentials },
                            colors = ButtonDefaults.buttonColors(containerColor = CyberSlate),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("SET ROOM", color = TextWhite, fontSize = 11.sp)
                        }

                        // Complete MATCH by setting typical GamerPro as winner
                        Button(
                            onClick = { viewModel.adminSetWinner(match, "GamerPro") },
                            colors = ButtonDefaults.buttonColors(containerColor = CyberRed),
                            modifier = Modifier.weight(1.5f)
                        ) {
                            Text("CLOSE & REWARD WINNER", fontSize = 11.sp)
                        }
                    }
                }
            } else {
                Box(
                    modifier = Modifier.fillMaxWidth().background(NeonGreen.copy(0.1f)).padding(6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Tournament Finished. Winner rewarded.", color = NeonGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}


// -------------------------------------------------------------
// 2. ADMIN PAYMENTS & FINANCE DEPOSIT QUEUE
// -------------------------------------------------------------
@Composable
fun AdminPaymentsSubScreen(
    viewModel: MainViewModel,
    transactions: List<TransactionEntity>,
    users: List<UserEntity>
) {
    val pendingTxns = transactions.filter { it.status == "Pending" }

    Text("PENDING TRANSFERS QUEUE (${pendingTxns.size})", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
    Spacer(modifier = Modifier.height(10.dp))

    if (pendingTxns.isEmpty()) {
        Box(
            modifier = Modifier.fillMaxWidth().height(150.dp).background(CyberSlate, RoundedCornerShape(8.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text("Transaction database queue is completely clean.", color = TextSoftAccent, fontSize = 12.sp)
        }
    } else {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(pendingTxns) { tx ->
                val targetUser = users.find { it.id == tx.userId }
                AdminPaymentRow(viewModel, tx, targetUser)
            }
        }
    }
}

@Composable
fun AdminPaymentRow(viewModel: MainViewModel, tx: TransactionEntity, user: UserEntity?) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CyberSlateElevated),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "${tx.type} Request - ৳${tx.amount}",
                    color = if (tx.type == "DEPOSIT") NeonGreen else CyberRed,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
                Text(
                    text = tx.status.uppercase(),
                    color = NeonYellow,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text("Player: ${user?.username ?: "Unknown User"} (ID: #${tx.userId})", color = TextWhite, fontSize = 13.sp)
            Text("Reference / Target Gateway info: ${tx.methodOrDetails}", color = TextSoftAccent, fontSize = 11.sp)

            Spacer(modifier = Modifier.height(12.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                Button(
                    onClick = { viewModel.adminApproveTransaction(tx) },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonGreen),
                    modifier = Modifier.weight(1f).testTag("approve_transaction_button")
                ) {
                    Text("APPROVE", color = DeepSpaceDark, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = { viewModel.adminRejectTransaction(tx) },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberRed),
                    modifier = Modifier.weight(1f).testTag("reject_transaction_button")
                ) {
                    Text("REJECT REASON", color = TextWhite)
                }
            }
        }
    }
}


// -------------------------------------------------------------
// 3. ADMIN TICKETS SUPPORT MANAGER
// -------------------------------------------------------------
@Composable
fun AdminTicketsSubScreen(
    viewModel: MainViewModel,
    tickets: List<TicketEntity>
) {
    val pendingTickets = tickets.filter { ticket -> ticket.reply.isBlank() }

    Text("PENDING SURVIVOR TICKETS (${pendingTickets.size})", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
    Spacer(modifier = Modifier.height(10.dp))

    if (pendingTickets.isEmpty()) {
        Box(
            modifier = Modifier.fillMaxWidth().height(150.dp).background(CyberSlate, RoundedCornerShape(8.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text("All support complaints are successfully resolved.", color = TextSoftAccent, fontSize = 12.sp)
        }
    } else {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(pendingTickets) { ticket ->
                AdminTicketReplyRow(viewModel, ticket)
            }
        }
    }
}

@Composable
fun AdminTicketReplyRow(viewModel: MainViewModel, ticket: TicketEntity) {
    var replyText by remember { mutableStateOf("") }

    Card(
        colors = CardDefaults.cardColors(containerColor = CyberSlateElevated),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(text = "Subject: ${ticket.subject}", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(text = "Player ID: #${ticket.userId}", color = NeoTeal, fontSize = 11.sp)
            Text(text = "Complaint Details: ${ticket.message}", color = TextSoftAccent, fontSize = 12.sp, modifier = Modifier.padding(vertical = 6.dp))

            Spacer(modifier = Modifier.height(4.dp))

            OutlinedTextField(
                value = replyText,
                onValueChange = { replyText = it },
                label = { Text("Type reply solution here...", color = TextSoftAccent) },
                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextWhite, unfocusedTextColor = TextWhite, focusedBorderColor = NeoTeal, unfocusedBorderColor = DeepSpaceDark),
                modifier = Modifier.fillMaxWidth().testTag("admin_reply_input")
            )

            Spacer(modifier = Modifier.height(10.dp))

            Button(
                onClick = { viewModel.adminReplyTicket(ticket, replyText) },
                colors = ButtonDefaults.buttonColors(containerColor = CyberRed),
                modifier = Modifier.fillMaxWidth().testTag("admin_reply_submit_button")
            ) {
                Text("SUBMIT REPLY SOLUTION", fontWeight = FontWeight.Bold)
            }
        }
    }
}


// -------------------------------------------------------------
// 4. ADMIN APP GLOBAL CONFIGS
// -------------------------------------------------------------
@Composable
fun AdminSettingsSubScreen(
    viewModel: MainViewModel,
    config: ConfigEntity?
) {
    if (config == null) return

    Column {
        Text("CREATOR GAME RULES MANAGEMENT", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Spacer(modifier = Modifier.height(16.dp))

        // Maintenance Toggle Button Row
        Surface(
            shape = RoundedCornerShape(10.dp),
            color = CyberSlateElevated,
            modifier = Modifier.fillMaxWidth().border(1.dp, BorderCyan, RoundedCornerShape(10.dp))
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("Global Maintenance Mode", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("Blocks normal gamers from registering tournaments", color = TextSoftAccent, fontSize = 11.sp)
                }

                Switch(
                    checked = config.maintenanceMode,
                    onCheckedChange = { viewModel.adminSaveConfig(config.copy(maintenanceMode = it)) },
                    colors = SwitchDefaults.colors(checkedThumbColor = CyberRed, checkedTrackColor = NeoTeal)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Configuration numeric adjustment inputs
        var minDepStr by remember { mutableStateOf(config.minDeposit.toString()) }
        var minWithStr by remember { mutableStateOf(config.minWithdraw.toString()) }
        var contactTgStr by remember { mutableStateOf(config.contactTelegram) }

        Card(
            colors = CardDefaults.cardColors(containerColor = CyberSlate),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("FINANCIAL TRADING THRESHOLDS", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = minDepStr,
                    onValueChange = { minDepStr = it },
                    label = { Text("Minimum Deposit Amount (৳)", color = TextSoftAccent) },
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextWhite, unfocusedTextColor = TextWhite, focusedBorderColor = NeoTeal, unfocusedBorderColor = DeepSpaceDark),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = minWithStr,
                    onValueChange = { minWithStr = it },
                    label = { Text("Minimum Cashout Amount (৳)", color = TextSoftAccent) },
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextWhite, unfocusedTextColor = TextWhite, focusedBorderColor = NeoTeal, unfocusedBorderColor = DeepSpaceDark),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = contactTgStr,
                    onValueChange = { contactTgStr = it },
                    label = { Text("Telegram Link (contact helper)", color = TextSoftAccent) },
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextWhite, unfocusedTextColor = TextWhite, focusedBorderColor = NeoTeal, unfocusedBorderColor = DeepSpaceDark),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        val d = minDepStr.toDoubleOrNull() ?: config.minDeposit
                        val w = minWithStr.toDoubleOrNull() ?: config.minWithdraw
                        viewModel.adminSaveConfig(
                            config.copy(
                                minDeposit = d,
                                minWithdraw = w,
                                contactTelegram = contactTgStr
                            )
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberRed),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("SAVE PARAMETERS", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
