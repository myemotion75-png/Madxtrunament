package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.TicketEntity
import com.example.data.TransactionEntity
import com.example.ui.MainViewModel
import com.example.ui.theme.*

// -------------------------------------------------------------
// 1. ESPORTS LOGIN / REGISTER HUB
// -------------------------------------------------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginRegisterScreen(
    viewModel: MainViewModel,
    onLoginSuccess: () -> Unit
) {
    var email by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    
    val uiError by viewModel.uiError.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()

    LaunchedEffect(currentUser) {
        if (currentUser != null) {
            onLoginSuccess()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepSpaceDark),
        contentAlignment = Alignment.Center
    ) {
        // Glowing background accent
        Box(
            modifier = Modifier
                .size(300.dp)
                .background(
                    Brush.radialGradient(
                        colors = listOf(CyberRed.copy(alpha = 0.15f), Color.Transparent)
                    )
                )
                .align(Alignment.TopCenter)
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // App Crest / Logo
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .background(CyberSlateElevated, RoundedCornerShape(16.dp))
                    .border(2.dp, CyberRed, RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Esports Logo",
                    tint = CyberRed,
                    modifier = Modifier.size(40.dp)
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "MAD TOURNAMENT",
                style = MaterialTheme.typography.displayLarge.copy(
                    color = TextWhite,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 28.sp
                ),
                textAlign = TextAlign.Center
            )

            Text(
                text = "RISE OF THE CHAMPIONS • FF MAX",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = NeoTeal,
                    letterSpacing = 2.sp
                ),
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 4.dp, bottom = 40.dp)
            )

            // Input Column Card
            Card(
                colors = CardDefaults.cardColors(containerColor = CyberSlate),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderCyan, RoundedCornerShape(16.dp))
            ) {
                Column(
                    modifier = Modifier.padding(20.dp)
                ) {
                    Text(
                        text = "PILOT ENTRY",
                        style = MaterialTheme.typography.titleLarge.copy(
                            color = TextWhite,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        ),
                        modifier = Modifier.padding(bottom = 16.dp)
                    )

                    OutlinedTextField(
                        value = username,
                        onValueChange = { username = it },
                        label = { Text("Gamer Username", color = TextSoftAccent) },
                        leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = NeoTeal) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeoTeal,
                            unfocusedBorderColor = CyberSlateElevated
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("username_input"),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("Account Email", color = TextSoftAccent) },
                        leadingIcon = { Icon(Icons.Default.Email, contentDescription = null, tint = NeoTeal) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeoTeal,
                            unfocusedBorderColor = CyberSlateElevated
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("email_input"),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                    )

                    if (uiError != null) {
                        Text(
                            text = uiError ?: "",
                            color = CyberRed,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Button(
                        onClick = { viewModel.login(email, username) },
                        colors = ButtonDefaults.buttonColors(containerColor = CyberRed),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("login_button")
                    ) {
                        Text(
                            "ENTER BATTLEGROUND",
                            fontWeight = FontWeight.Bold,
                            color = TextWhite,
                            letterSpacing = 1.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Fast login helper for testing
            Text(
                "TESTING SHORTCUTS",
                color = TextSoftAccent,
                fontSize = 11.sp,
                style = MaterialTheme.typography.labelSmall
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = {
                        username = "GamerPro"
                        email = "player@mad.com"
                        viewModel.login(email, username)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberSlateElevated),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Gamer Dev", color = NeoTeal, fontSize = 11.sp)
                }

                Button(
                    onClick = {
                        username = "MadAdmin"
                        email = "admin@mad.com"
                        viewModel.login(email, username)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberSlateElevated),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Admin Pass", color = CyberRed, fontSize = 11.sp)
                }
            }
        }
    }
}


// -------------------------------------------------------------
// 2. CRYPTO & WALLET (DEPOSIT & WITHDRAWAL SCREEN)
// -------------------------------------------------------------
@Composable
fun WalletScreen(viewModel: MainViewModel) {
    val currentUser by viewModel.currentUser.collectAsState()
    val myTransactions by viewModel.myTransactions.collectAsState()
    val appConfig by viewModel.appConfig.collectAsState()
    val uiError by viewModel.uiError.collectAsState()
    val uiSuccess by viewModel.uiSuccess.collectAsState()

    var activeTab by remember { mutableStateOf("DEPOSIT") } // "DEPOSIT" vs "WITHDRAW"
    var amountText by remember { mutableStateOf("") }
    var channelMethod by remember { mutableStateOf("Bkash") } // Bkash, Nagad, Rocket
    var accountOrTxn by remember { mutableStateOf("") }

    DisposableEffect(Unit) {
        onDispose { viewModel.clearMessages() }
    }

    Scaffold(
        topBar = {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CyberSlate)
                    .padding(16.dp)
            ) {
                Text(
                    text = "WALLET DEPOSIT & WITHDRAWAL",
                    color = TextWhite,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    modifier = Modifier.align(Alignment.CenterStart)
                )
                Text(
                    text = "BACK",
                    color = NeoTeal,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .clickable { viewModel.setScreen("dashboard") }
                )
            }
        },
        containerColor = DeepSpaceDark
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            // Balance Card
            Card(
                colors = CardDefaults.cardColors(containerColor = CyberSlate),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderCyan, RoundedCornerShape(12.dp))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("AVAILABLE BALANCE", color = TextSoftAccent, fontSize = 13.sp)
                    Text(
                        text = "৳ ${String.format("%.2f", currentUser?.walletBalance ?: 0.0)}",
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Black,
                        color = NeoTeal,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                    Text(
                        "UserID: #${currentUser?.id ?: 0} | Username: ${currentUser?.username ?: "Guest"}",
                        color = TextWhite.copy(alpha = 0.7f),
                        fontSize = 12.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Navigation Tabs (Deposit vs Withdraw)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CyberSlate, RoundedCornerShape(8.dp))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                val depositActive = activeTab == "DEPOSIT"
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(
                            if (depositActive) CyberRed else Color.Transparent,
                            RoundedCornerShape(6.dp)
                        )
                        .clickable { activeTab = "DEPOSIT" }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "ADD DEPOSIT",
                        fontWeight = FontWeight.Bold,
                        color = if (depositActive) TextWhite else TextSoftAccent,
                        fontSize = 13.sp
                    )
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(
                            if (!depositActive) CyberRed else Color.Transparent,
                            RoundedCornerShape(6.dp)
                        )
                        .clickable { activeTab = "WITHDRAW" }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "REQUEST OUT",
                        fontWeight = FontWeight.Bold,
                        color = if (!depositActive) TextWhite else TextSoftAccent,
                        fontSize = 13.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Action form card
            Card(
                colors = CardDefaults.cardColors(containerColor = CyberSlateElevated),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (activeTab == "DEPOSIT") "DEPOSIT TRANSFERS" else "WITHDRAWAL TRANSFERS",
                        color = TextWhite,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    // Error & Success Feedbacks
                    if (uiError != null) {
                        Text(uiError ?: "", color = CyberRed, fontSize = 12.sp, modifier = Modifier.padding(bottom = 8.dp))
                    }
                    if (uiSuccess != null) {
                        Text(uiSuccess ?: "", color = NeonGreen, fontSize = 12.sp, modifier = Modifier.padding(bottom = 8.dp))
                    }

                    // Input Value
                    OutlinedTextField(
                        value = amountText,
                        onValueChange = { amountText = it },
                        label = { Text("Amount (৳)", color = TextSoftAccent) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextWhite,
                            unfocusedTextColor = TextWhite,
                            focusedBorderColor = NeoTeal,
                            unfocusedBorderColor = CyberSlate
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("transaction_amount_input"),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // payment gateway options row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("Bkash", "Nagad", "Rocket").forEach { method ->
                            val selected = channelMethod == method
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .background(
                                        if (selected) NeoTeal.copy(0.15f) else Color.Transparent,
                                        RoundedCornerShape(6.dp)
                                    )
                                    .border(
                                        1.dp,
                                        if (selected) NeoTeal else CyberSlate,
                                        RoundedCornerShape(6.dp)
                                    )
                                    .clickable { channelMethod = method }
                                    .padding(vertical = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = method,
                                    fontWeight = FontWeight.Bold,
                                    color = if (selected) NeoTeal else TextSoftAccent,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Account transaction ID input
                    OutlinedTextField(
                        value = accountOrTxn,
                        onValueChange = { accountOrTxn = it },
                        label = {
                            Text(
                                text = if (activeTab == "DEPOSIT") "Enter Transaction ID (TxID)" else "Enter Cashout Mobile Number",
                                color = TextSoftAccent
                            )
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextWhite,
                            unfocusedTextColor = TextWhite,
                            focusedBorderColor = NeoTeal,
                            unfocusedBorderColor = CyberSlate
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("transaction_details_input"),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            val amount = amountText.toDoubleOrNull() ?: 0.0
                            if (activeTab == "DEPOSIT") {
                                viewModel.depositMoney(amount, "$channelMethod | TxId: $accountOrTxn")
                            } else {
                                viewModel.withdrawMoney(amount, "$channelMethod | Num: $accountOrTxn")
                            }
                            amountText = ""
                            accountOrTxn = ""
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CyberRed),
                        modifier = Modifier.fillMaxWidth().testTag("transaction_submit_button"),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = if (activeTab == "DEPOSIT") "SUBMIT FOR REVIEW" else "REQUEST CASHOUT NOW",
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Transactions History
            Text(
                "TRANSACTION STATEMENT HISTORY",
                color = TextWhite,
                fontWeight = FontWeight.SemiBold,
                fontSize = 13.sp,
                modifier = Modifier.padding(bottom = 10.dp)
            )

            if (myTransactions.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .background(CyberSlate, RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No transactions logged in this tournament account.", color = TextSoftAccent)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(myTransactions) { tx ->
                        TransactionRow(tx)
                    }
                }
            }
        }
    }
}

@Composable
fun TransactionRow(tx: TransactionEntity) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CyberSlate),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "${tx.type} - ${tx.methodOrDetails}",
                    color = TextWhite,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Text(
                    text = "Ref: #${tx.id} | Timestamp: ${tx.timestamp}",
                    color = TextSoftAccent,
                    fontSize = 11.sp
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                val isNegative = tx.type == "ENTRY_FEE" || tx.type == "WITHDRAW"
                Text(
                    text = "${if (isNegative) "-" else "+"} ৳${tx.amount}",
                    color = if (isNegative) CyberRed else NeonGreen,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )

                // Status Badge
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = when (tx.status) {
                        "Success" -> NeonGreen.copy(0.15f)
                        "Pending" -> NeonYellow.copy(0.15f)
                        else -> CyberRed.copy(0.15f)
                    },
                    modifier = Modifier.padding(top = 4.dp)
                ) {
                    Text(
                        text = tx.status.uppercase(),
                        color = when (tx.status) {
                            "Success" -> NeonGreen
                            "Pending" -> NeonYellow
                            else -> CyberRed
                        },
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
        }
    }
}


// -------------------------------------------------------------
// 3. SUPPORT HELPDESK & TICKETS SCREEN
// -------------------------------------------------------------
@Composable
fun SupportScreen(viewModel: MainViewModel) {
    var subject by remember { mutableStateOf("") }
    var msgText by remember { mutableStateOf("") }

    val myTickets by viewModel.myTickets.collectAsState()
    val uiError by viewModel.uiError.collectAsState()
    val uiSuccess by viewModel.uiSuccess.collectAsState()
    val appConfig by viewModel.appConfig.collectAsState()

    DisposableEffect(Unit) {
        onDispose { viewModel.clearMessages() }
    }

    Scaffold(
        topBar = {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CyberSlate)
                    .padding(16.dp)
            ) {
                Text(
                    text = "SUPPORT HELPDESK",
                    color = TextWhite,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    modifier = Modifier.align(Alignment.CenterStart)
                )
                Text(
                    text = "BACK",
                    color = NeoTeal,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .clickable { viewModel.setScreen("dashboard") }
                )
            }
        },
        containerColor = DeepSpaceDark
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            // Telegram support shortcut banner
            Card(
                colors = CardDefaults.cardColors(containerColor = NeoTeal.copy(0.1f)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, NeoTeal.copy(0.4f), RoundedCornerShape(10.dp))
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Send, contentDescription = "Telegram Support", tint = NeoTeal)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text("Connect on Telegram Support", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text(appConfig?.contactTelegram ?: "t.me/MadTournamentSupport", color = NeoTeal, fontSize = 11.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Create Ticket Form
            Card(
                colors = CardDefaults.cardColors(containerColor = CyberSlate),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("OPEN NEW TICKET", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)

                    Spacer(modifier = Modifier.height(12.dp))

                    if (uiError != null) {
                        Text(uiError ?: "", color = CyberRed, fontSize = 12.sp, modifier = Modifier.padding(bottom = 8.dp))
                    }
                    if (uiSuccess != null) {
                        Text(uiSuccess ?: "", color = NeonGreen, fontSize = 12.sp, modifier = Modifier.padding(bottom = 8.dp))
                    }

                    OutlinedTextField(
                        value = subject,
                        onValueChange = { subject = it },
                        label = { Text("Topic / Subject (e.g. Deposit Late)", color = TextSoftAccent) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextWhite,
                            unfocusedTextColor = TextWhite,
                            focusedBorderColor = NeoTeal,
                            unfocusedBorderColor = DeepSpaceDark
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("ticket_subject_input")
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = msgText,
                        onValueChange = { msgText = it },
                        label = { Text("Explain your problem clearly", color = TextSoftAccent) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextWhite,
                            unfocusedTextColor = TextWhite,
                            focusedBorderColor = NeoTeal,
                            unfocusedBorderColor = DeepSpaceDark
                        ),
                        modifier = Modifier.fillMaxWidth().height(100.dp).testTag("ticket_message_input")
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            viewModel.submitSupportTicket(subject, msgText)
                            subject = ""
                            msgText = ""
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CyberRed),
                        modifier = Modifier.fillMaxWidth().testTag("ticket_submit_button")
                    ) {
                        Text("SUBMIT COMPLAINT", fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Ticket history list
            Text("YOUR ACTIVE & SOLVED COMPLAINTS", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)

            Spacer(modifier = Modifier.height(10.dp))

            if (myTickets.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .background(CyberSlate, RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No tickets matching your registration history.", color = TextSoftAccent)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(myTickets) { ticket ->
                        TicketRowItem(ticket)
                    }
                }
            }
        }
    }
}

@Composable
fun TicketRowItem(ticket: TicketEntity) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CyberSlateElevated),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = ticket.subject,
                    color = TextWhite,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )

                // Ticket Status Badging
                val isResolved = ticket.status == "Resolved"
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = if (isResolved) NeonGreen.copy(0.15f) else NeonYellow.copy(0.15f)
                ) {
                    Text(
                        text = ticket.status.uppercase(),
                        color = if (isResolved) NeonGreen else NeonYellow,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text("Problem details: ${ticket.message}", color = TextSoftAccent, fontSize = 12.sp)

            if (ticket.reply.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(DeepSpaceDark, RoundedCornerShape(6.dp))
                        .padding(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Notifications,
                        contentDescription = "Response Icon",
                        tint = NeoTeal,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Admin response: ${ticket.reply}",
                        color = TextWhite,
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}
