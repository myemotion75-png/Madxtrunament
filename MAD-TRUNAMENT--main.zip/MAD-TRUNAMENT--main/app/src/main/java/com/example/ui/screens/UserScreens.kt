package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MatchEntity
import com.example.data.UserEntity
import com.example.ui.MainViewModel
import com.example.ui.theme.*

// -------------------------------------------------------------
// 1. ESPORTS USER DASHBOARD & BOTTOM NAVIGATION LAYOUT
// -------------------------------------------------------------
@Composable
fun TournamentDashboard(viewModel: MainViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    var selectedTab by remember { mutableStateOf("MATCHES") } // "MATCHES", "LEADERBOARD", "PROFILE"

    val matches by viewModel.matchesList.collectAsState()
    val users by viewModel.adminAllUsers.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()

    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = CyberSlate,
                modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
            ) {
                NavigationBarItem(
                    selected = selectedTab == "MATCHES",
                    onClick = { selectedTab = "MATCHES" },
                    icon = { Icon(Icons.Default.PlayArrow, contentDescription = "Matches", tint = if (selectedTab == "MATCHES") CyberRed else TextSoftAccent) },
                    label = { Text("Fights", color = if (selectedTab == "MATCHES") TextWhite else TextSoftAccent, fontSize = 11.sp) }
                )

                NavigationBarItem(
                    selected = selectedTab == "LEADERBOARD",
                    onClick = { selectedTab = "LEADERBOARD" },
                    icon = { Icon(Icons.Default.Star, contentDescription = "Leaderboard", tint = if (selectedTab == "LEADERBOARD") CyberRed else TextSoftAccent) },
                    label = { Text("Top Guys", color = if (selectedTab == "LEADERBOARD") TextWhite else TextSoftAccent, fontSize = 11.sp) }
                )

                NavigationBarItem(
                    selected = selectedTab == "PROFILE",
                    onClick = { selectedTab = "PROFILE" },
                    icon = { Icon(Icons.Default.Person, contentDescription = "Profile", tint = if (selectedTab == "PROFILE") CyberRed else TextSoftAccent) },
                    label = { Text("Survivor", color = if (selectedTab == "PROFILE") TextWhite else TextSoftAccent, fontSize = 11.sp) }
                )
            }
        },
        containerColor = DeepSpaceDark
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                "MATCHES" -> MatchesListSubScreen(viewModel, matches)
                "LEADERBOARD" -> LeaderboardSubScreen(users)
                "PROFILE" -> ProfileSubScreen(viewModel, currentUser)
            }
        }
    }
}


// -------------------------------------------------------------
// 2. MATCH COHESIVE CARD & REGISTRATION SCREEN
// -------------------------------------------------------------
@Composable
fun MatchesListSubScreen(viewModel: MainViewModel, matches: List<MatchEntity>) {
    var selectedMatchForJoin by remember { mutableStateOf<MatchEntity?>(null) }
    val myRegistrations by viewModel.myRegistrations.collectAsState()
    val uiError by viewModel.uiError.collectAsState()
    val uiSuccess by viewModel.uiSuccess.collectAsState()

    DisposableEffect(Unit) {
        onDispose { viewModel.clearMessages() }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Top Banner / Promotion
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(130.dp)
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(CyberRed.copy(0.85f), CyberSlateElevated)
                    ),
                    RoundedCornerShape(12.dp)
                )
                .border(1.dp, BorderCyan, RoundedCornerShape(12.dp))
                .padding(16.dp)
        ) {
            Column(modifier = Modifier.align(Alignment.CenterStart)) {
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = Color.Black.copy(0.4f)
                ) {
                    Text(
                        "ACTIVE BATTLE SEASON",
                        color = NeoTeal,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "FREE FIRE MATCHES",
                    color = TextWhite,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 20.sp
                )

                Text(
                    text = "Register with entry fee to win total mega prizes",
                    color = TextSoftAccent,
                    fontSize = 11.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "TOURNAMENTS PLAY LIST",
            color = TextWhite,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        if (uiSuccess != null) {
            Card(
                colors = CardDefaults.cardColors(containerColor = NeonGreen.copy(0.1f)),
                modifier = Modifier.padding(bottom = 12.dp).fillMaxWidth().border(1.dp, NeonGreen, RoundedCornerShape(6.dp))
            ) {
                Text(uiSuccess ?: "", color = NeonGreen, fontWeight = FontWeight.Bold, modifier = Modifier.padding(12.dp), fontSize = 13.sp)
            }
        }
        if (uiError != null) {
            Card(
                colors = CardDefaults.cardColors(containerColor = CyberRed.copy(0.1f)),
                modifier = Modifier.padding(bottom = 12.dp).fillMaxWidth().border(1.dp, CyberRed, RoundedCornerShape(6.dp))
            ) {
                Text(uiError ?: "", color = CyberRed, fontWeight = FontWeight.Bold, modifier = Modifier.padding(12.dp), fontSize = 13.sp)
            }
        }

        if (matches.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(CyberSlate, RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text("Searching active matches...", color = TextSoftAccent)
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(matches) { match ->
                    val alreadyJoined = myRegistrations.any { it.matchId == match.id }
                    MatchCard(
                        match = match,
                        alreadyJoined = alreadyJoined,
                        onJoinClick = { selectedMatchForJoin = match }
                    )
                }
            }
        }
    }

    if (selectedMatchForJoin != null) {
        val current = selectedMatchForJoin!!
        val alreadyJoined = myRegistrations.any { it.matchId == current.id }
        
        JoinMatchDialog(
            match = current,
            alreadyJoined = alreadyJoined,
            onDismiss = { selectedMatchForJoin = null },
            onJoinConfirm = { nick, guid ->
                viewModel.joinMatch(current, nick, guid)
                selectedMatchForJoin = null
            }
        )
    }
}

@Composable
fun MatchCard(
    match: MatchEntity,
    alreadyJoined: Boolean,
    onJoinClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CyberSlate),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                if (alreadyJoined) NeoTeal.copy(0.6f) else BorderRed,
                RoundedCornerShape(12.dp)
            )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = CyberRed.copy(0.15f)
                ) {
                    Text(
                        text = match.gameName.uppercase(),
                        color = CyberRed,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }

                Text(
                    text = match.dateTime,
                    color = NeonYellow,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 12.sp
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = match.title,
                color = TextWhite,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Game specification details
            Row(
                modifier = Modifier.fillMaxWidth().background(CyberSlateElevated, RoundedCornerShape(6.dp)).padding(8.dp),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("PRIZE POOL", color = TextSoftAccent, fontSize = 10.sp)
                    Text("৳${match.totalPrize}", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("ENTRY FEE", color = TextSoftAccent, fontSize = 10.sp)
                    Text("৳${match.entryFee}", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("PER KILL", color = TextSoftAccent, fontSize = 10.sp)
                    Text("৳${match.killPrize}", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("MAP / TEAM", color = TextSoftAccent, fontSize = 10.sp)
                    Text("${match.map} / ${match.matchType}", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Slots tracking slider
            val slotsPercentage = if (match.maxPlayers > 0) match.joinedCount.toFloat() / match.maxPlayers else 0f
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Filled: ${match.joinedCount}/${match.maxPlayers}",
                    color = TextSoftAccent,
                    fontSize = 11.sp
                )
                Text(
                    text = if (match.joinedCount >= match.maxPlayers) "Slots Full" else "${match.maxPlayers - match.joinedCount} Left",
                    color = if (match.joinedCount >= match.maxPlayers) CyberRed else NeoTeal,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            LinearProgressIndicator(
                progress = slotsPercentage,
                color = CyberRed,
                trackColor = DeepSpaceDark,
                modifier = Modifier.fillMaxWidth().height(6.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            // If match is completed, show Winner
            if (match.isCompleted) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(NeonGreen.copy(0.12f), RoundedCornerShape(6.dp))
                        .padding(10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "CHAMPION: ${match.winnerName.uppercase()} 🏆",
                        color = NeonGreen,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 13.sp
                    )
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Action controls
                    if (alreadyJoined) {
                        Button(
                            onClick = onJoinClick, // Clicking displays details/creds
                            colors = ButtonDefaults.buttonColors(containerColor = NeoTeal.copy(0.2f)),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.weight(1.5f).border(1.dp, NeoTeal, RoundedCornerShape(6.dp))
                        ) {
                            Text("VIEW ROOM CREDENTIALS KEY", color = NeoTeal, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    } else {
                        Button(
                            onClick = onJoinClick,
                            enabled = match.joinedCount < match.maxPlayers,
                            colors = ButtonDefaults.buttonColors(containerColor = CyberRed),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.weight(1f).testTag("join_tournament_button")
                        ) {
                            Text("JOIN FIGHT", color = TextWhite, fontWeight = FontWeight.Black)
                        }
                    }
                }
            }
        }
    }
}


// Join Match Form Dialog
@Composable
fun JoinMatchDialog(
    match: MatchEntity,
    alreadyJoined: Boolean,
    onDismiss: () -> Unit,
    onJoinConfirm: (String, String) -> Unit
) {
    if (alreadyJoined) {
        AlertDialog(
            onDismissRequest = onDismiss,
            containerColor = CyberSlate,
            title = { Text("MATCH CREDENTIALS", color = TextWhite, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("You have successfully registered for: ${match.title}", color = TextSoftAccent, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(16.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(DeepSpaceDark, RoundedCornerShape(8.dp))
                            .border(1.dp, NeoTeal, RoundedCornerShape(8.dp))
                            .padding(16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (match.roomCredentials.isNotBlank()) match.roomCredentials else "Room ID and Pass will list here 15 mins before action.",
                            color = NeoTeal,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            fontSize = 15.sp
                        )
                    }
                }
            },
            confirmButton = {
                Button(onClick = onDismiss, colors = ButtonDefaults.buttonColors(containerColor = CyberRed)) {
                    Text("READY GO", color = TextWhite)
                }
            }
        )
    } else {
        var igName by remember { mutableStateOf("") }
        var igId by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = onDismiss,
            containerColor = CyberSlate,
            title = { Text("FIGHT REGISTRATION", color = TextWhite, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text(
                        text = "Match Fee: ৳${match.entryFee} will be deducted from your wallet balance.",
                        color = NeonYellow,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    OutlinedTextField(
                        value = igName,
                        onValueChange = { igName = it },
                        label = { Text("In-Game Name (IGN)", color = TextSoftAccent) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextWhite,
                            unfocusedTextColor = TextWhite,
                            focusedBorderColor = NeoTeal,
                            unfocusedBorderColor = DeepSpaceDark
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("ign_input"),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = igId,
                        onValueChange = { igId = it },
                        label = { Text("In-Game UID", color = TextSoftAccent) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextWhite,
                            unfocusedTextColor = TextWhite,
                            focusedBorderColor = NeoTeal,
                            unfocusedBorderColor = DeepSpaceDark
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("ig_uid_input"),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = { onJoinConfirm(igName, igId) },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberRed),
                    modifier = Modifier.testTag("confirm_join_button")
                ) {
                    Text("CONFIRM REGISTER", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = onDismiss) {
                    Text("CANCEL", color = TextSoftAccent)
                }
            }
        )
    }
}


// -------------------------------------------------------------
// 3. LEADERBOARD SCREEN
// -------------------------------------------------------------
@Composable
fun LeaderboardSubScreen(users: List<UserEntity>) {
    val sortedUsers = users.sortedByDescending { it.walletBalance }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            "SURVIVORS TOP WINNERS ELITE",
            color = TextWhite,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 18.sp,
            modifier = Modifier.padding(bottom = 14.dp)
        )

        Card(
            colors = CardDefaults.cardColors(containerColor = CyberSlate),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 14.dp)
                .border(1.dp, BorderCyan, RoundedCornerShape(12.dp))
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Star, contentDescription = "Trophy", tint = NeonYellow, modifier = Modifier.size(32.dp))
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text("PRO LEAGUE EARNINGS", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("The competitive arena standings by tournament statistics.", color = TextSoftAccent, fontSize = 11.sp)
                }
            }
        }

        if (sortedUsers.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(CyberSlate, RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text("Summoning leaderboard data...", color = TextSoftAccent)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                itemsIndexed(sortedUsers) { index, player ->
                    val rank = index + 1
                    LeaderboardRowItem(rank, player)
                }
            }
        }
    }
}

@Composable
fun LeaderboardRowItem(rank: Int, player: UserEntity) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CyberSlateElevated),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Rank Number Badge
            Surface(
                shape = RoundedCornerShape(4.dp),
                color = when (rank) {
                    1 -> CyberRed
                    2 -> NeoTeal
                    3 -> NeonYellow
                    else -> Color.Black.copy(0.4f)
                },
                modifier = Modifier.size(28.dp),
                contentColor = TextWhite
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(rank.toString(), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(player.username, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(player.email, color = TextSoftAccent, fontSize = 11.sp)
            }

            Text(
                "৳${String.format("%.0f", player.walletBalance)}",
                color = NeoTeal,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 15.sp
            )
        }
    }
}


// -------------------------------------------------------------
// 4. SURVIVOR PROFILE SCREEN
// -------------------------------------------------------------
@Composable
fun ProfileSubScreen(viewModel: MainViewModel, currentUser: UserEntity?) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            "COMPETITIVE ID PROFILE",
            color = TextWhite,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 18.sp,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        // Core Profile Badge Container
        Card(
            colors = CardDefaults.cardColors(containerColor = CyberSlate),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(2.dp, BorderCyan, RoundedCornerShape(12.dp))
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Circle Profile Avatar Emblem
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .background(CyberSlateElevated, RoundedCornerShape(36.dp))
                        .border(1.5.dp, CyberRed, RoundedCornerShape(36.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = "User Avatar",
                        tint = CyberRed,
                        modifier = Modifier.size(36.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = currentUser?.username ?: "SurviverName",
                    color = TextWhite,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )

                Text(
                    text = currentUser?.email ?: "gamer@esports.com",
                    color = TextSoftAccent,
                    fontSize = 12.sp
                )

                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("WALLET BUDGET", color = TextSoftAccent, fontSize = 11.sp)
                        Text("৳${currentUser?.walletBalance ?: 0.0}", color = NeoTeal, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("MEMBER CLASS", color = TextSoftAccent, fontSize = 11.sp)
                        Text(
                            text = if (currentUser?.isAdmin == true) "ADMINISTRATOR" else "PRO PLAYER",
                            color = if (currentUser?.isAdmin == true) CyberRed else NeonYellow,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Actions navigation cards
        Text("ACCOUNT FINANCES & ASSISTANCE", color = TextSoftAccent, fontSize = 12.sp, modifier = Modifier.padding(bottom = 8.dp))

        Card(
            colors = CardDefaults.cardColors(containerColor = CyberSlate),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column {
                ProfileOptionRow(
                    label = "Wallet Cashier (Deposit/Withdraw)",
                    subText = "Manage your credits, bank deposit and withdraw requests",
                    icon = Icons.Default.Build,
                    onClick = { viewModel.setScreen("wallet") }
                )

                Divider(color = DeepSpaceDark, thickness = 1.dp)

                ProfileOptionRow(
                    label = "Helpdesk Support Tickets",
                    subText = "Write complain issues about games or balance to creators",
                    icon = Icons.Default.Send,
                    onClick = { viewModel.setScreen("tickets") }
                )

                if (currentUser?.isAdmin == true) {
                    Divider(color = DeepSpaceDark, thickness = 1.dp)
                    ProfileOptionRow(
                        label = "Admin Control Panel",
                        subText = "Access creator dashboards to add fights and logs",
                        icon = Icons.Default.Notifications,
                        onClick = { viewModel.setScreen("admin") }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        Button(
            onClick = { viewModel.logout() },
            colors = ButtonDefaults.buttonColors(containerColor = CyberRed),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("END USER SESSION (LOGOUT)", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun ProfileOptionRow(
    label: String,
    subText: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = NeoTeal, modifier = Modifier.size(24.dp))
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(label, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(subText, color = TextSoftAccent, fontSize = 11.sp)
        }
        Icon(Icons.Default.ArrowForward, contentDescription = null, tint = TextSoftAccent, modifier = Modifier.size(16.dp))
    }
}
